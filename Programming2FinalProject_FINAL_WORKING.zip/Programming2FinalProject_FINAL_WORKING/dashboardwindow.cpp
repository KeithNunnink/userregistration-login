#include "dashboardwindow.h"
#include "ui_dashboardwindow.h"
#include "passwordutils.h"
#include <QMessageBox>
#include <QInputDialog>
#include <QLineEdit>
#include <QDateTime>

DashboardWindow::DashboardWindow(User &user, QWidget *parent)
    : QDialog(parent),
    ui(new Ui::DashboardWindow),
    loggedInUser(user)
{
    ui->setupUi(this);
    ui->labelWelcome->setText("Welcome, " + loggedInUser.username + "!");
}

DashboardWindow::~DashboardWindow()
{
    delete ui;
}

void DashboardWindow::on_pushButton_ViewInfo_clicked()
{

    QString info = "Username: " + loggedInUser.username +
                   "\nEmail: " + loggedInUser.email +
                   "\nStudent ID: " + loggedInUser.studentID +
                   "\n\nAccount history:\n" + loggedInUser.loginAttempts.join("\n"); // Now valid since loginAttempts is a QStringList

    ui->textEdit_UserInfo->setText(info);
}

void DashboardWindow::on_pushButton_Logout_clicked()
{
    this->close();
}

void DashboardWindow::on_pushButton_ChangePassword_clicked()
{
    bool ok;

    QString oldPassword = QInputDialog::getText(this, "Verify Password", "Enter your current password:",
                                                QLineEdit::Password, "", &ok);
    if (!ok) return;

    // Hash the entered password to compare with stored hash
    if (PasswordUtils::hashPassword(oldPassword) != loggedInUser.password) {
        QMessageBox::warning(this, "Error", "Current password is incorrect.");
        return;
    }

    QString newPassword = QInputDialog::getText(this, "New Password", "Enter new password:",
                                                QLineEdit::Password, "", &ok);
    if (!ok || newPassword.isEmpty()) return;

    QString confirmPassword = QInputDialog::getText(this, "Confirm Password", "Confirm new password:",
                                                    QLineEdit::Password, "", &ok);
    if (!ok || confirmPassword.isEmpty()) return;

    if (newPassword != confirmPassword) {
        QMessageBox::warning(this, "Error", "Passwords don't match.");
        return;
    }

    // Hash the new password before storing
    loggedInUser.password = PasswordUtils::hashPassword(newPassword);
    QMessageBox::information(this, "Success", "Password changed successfully.");
}
