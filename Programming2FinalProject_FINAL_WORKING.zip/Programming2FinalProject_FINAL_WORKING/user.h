#ifndef USER_H
#define USER_H

#include <QString>
#include <QStringList>
#include <QTextStream>

struct User {
    QString username;
    QString password;
    QString email;
    QString studentID;
    QStringList loginAttempts;
    bool admin = false;
    int failedAttempts = 0;  // Track failed login attempts
    bool accountLocked = false;  // Track if account is locked

    User() = default;

    User(const QString& uname, const QString& mail, const QString& id, const QString& pwd, bool isAdmin = false)
        : username(uname), password(pwd), email(mail), studentID(id), admin(isAdmin) {}

    // Serialize user data to CSV format
    QString toCsv() const {
        return QString("%1,%2,%3,%4,%5,%6,%7,%8")
            .arg(username, password, email, studentID, admin ? "1" : "0", loginAttempts.join(";"), QString::number(failedAttempts), accountLocked ? "1" : "0");
    }

    // Deserialize user data from CSV format
    static User fromCsv(const QString& csvLine) {
        QStringList fields = csvLine.split(",");
        if (fields.size() < 8) return User();
        User user(fields[0], fields[2], fields[3], fields[1], fields[4] == "1");
        user.loginAttempts = fields[5].split(";");
        user.failedAttempts = fields[6].toInt();
        user.accountLocked = fields[7] == "1";
        return user;
    }
};

#endif // USER_H
